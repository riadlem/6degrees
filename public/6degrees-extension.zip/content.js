;(function () {
  "use strict"

  if (!window.location.pathname.startsWith("/in/")) return

  // ─── Shadow DOM host ──────────────────────────────────────────────────────────
  // We render the FAB and panel inside a shadow root so:
  //   1. LinkedIn's nonce-based CSP cannot block our styles (extension URL origin)
  //   2. LinkedIn's own CSS cannot bleed into our UI (shadow encapsulation)

  let _shadow = null

  function getShadow() {
    if (_shadow) return _shadow

    const host = document.createElement("div")
    host.id = "sd-root"
    // Reset all inherited styles on the host so LinkedIn's global CSS can't
    // affect the shadow root container itself.
    host.style.cssText = "all: initial; position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483639; overflow: visible; pointer-events: none;"
    document.body.appendChild(host)

    _shadow = host.attachShadow({ mode: "open" })

    // Load styles from extension origin — bypasses the page's CSP entirely.
    const link = document.createElement("link")
    link.rel = "stylesheet"
    link.href = chrome.runtime.getURL("content.css")
    _shadow.appendChild(link)

    return _shadow
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  function q(selectors, root = document) {
    for (const sel of selectors) {
      try {
        const el = root.querySelector(sel)
        if (el) return el
      } catch { /* invalid selector — skip */ }
    }
    return null
  }

  function text(selectors, root = document) {
    const el = q(selectors, root)
    return el ? el.textContent.trim() || null : null
  }

  // ─── Scraper ─────────────────────────────────────────────────────────────────

  function slugFromUrl() {
    return window.location.pathname
      .replace(/^\/in\//, "")
      .replace(/\/$/, "")
      .split("/")[0] ?? ""
  }

  function humanizeSlug(slug) {
    const parts = slug
      .split("-")
      .filter((p) => p.length > 0 && !/^\d+$/.test(p))
      .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
    if (parts.length === 0) return { firstName: slug || "Unknown", lastName: null }
    if (parts.length === 1) return { firstName: parts[0], lastName: null }
    return { firstName: parts.slice(0, -1).join(" "), lastName: parts[parts.length - 1] }
  }

  function scrapeName() {
    const selectors = [
      "h1.text-heading-xlarge",
      "h1[class*='text-heading']",
      ".pv-text-details__left-panel h1",
      ".ph5 h1",
      "section.artdeco-card h1",
      "main h1",
      "h1",
    ]
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel)
        if (!el) continue
        const inner = el.querySelector("span[aria-hidden='true']")
        const full = ((inner ?? el).textContent ?? "").trim()
        if (!full || full.length > 100) continue
        const parts = full.split(/\s+/).filter(Boolean)
        if (parts.length >= 1) {
          return { firstName: parts[0], lastName: parts.slice(1).join(" ") || null }
        }
      } catch { /* continue */ }
    }
    // Reliable fallback: page title is always "First Last - Headline | LinkedIn"
    const titleName = (document.title || "").split("|")[0].split(" - ")[0].trim()
    if (titleName && titleName.length > 1 && titleName !== "LinkedIn") {
      const parts = titleName.split(/\s+/).filter(Boolean)
      if (parts.length >= 2) return { firstName: parts[0], lastName: parts.slice(1).join(" ") }
      if (parts.length === 1) return { firstName: parts[0], lastName: null }
    }
    console.debug("[6Degrees] name not found, falling back to URL slug")
    return humanizeSlug(slugFromUrl())
  }

  // Upgrade LinkedIn CDN URLs to 400×400 resolution.
  // LinkedIn media URLs contain a size suffix like "shrink_100_100" or "shrink_200_200".
  // Replacing it with "shrink_400_400" requests a higher-res version the CDN always has.
  function upgradePhotoUrl(src) {
    if (!src) return src
    // Replace any shrink_NxN with 400×400 (covers 100, 200, 800, etc.)
    return src.replace(/shrink_\d+_\d+/g, "shrink_400_400")
  }

  function imgSrc(img) {
    return (
      img.src ||
      img.getAttribute("data-delayed-url") ||
      img.getAttribute("data-ghost-url") ||
      img.currentSrc ||
      ""
    )
  }

  // Returns true if the image element has a squarish aspect ratio (profile photos are ~1:1).
  // Banners are ~4:1 or wider. We reject anything wider than 2× its height.
  function isSquarishImage(img) {
    const w = img.naturalWidth  || img.getBoundingClientRect().width  || img.width  || 0
    const h = img.naturalHeight || img.getBoundingClientRect().height || img.height || 0
    if (!w || !h) return true  // dimensions unknown — don't reject
    return (w / h) < 2.5
  }

  function scrapePhoto() {
    // ── Strategy 1: tight profile-photo containers ────────────────────────────
    // Search for imgs / picture sources *only* inside the known profile-photo
    // wrapper elements.  This avoids picking up the cover/banner which sits
    // higher in the DOM in most picture-element passes.
    const photoRoots = [
      document.querySelector(".pv-top-card-profile-picture"),
      document.querySelector(".profile-photo-edit__container"),
      document.querySelector(".pv-top-card__photo-wrapper"),
      document.querySelector("[data-anonymize='headshot-photo']")?.closest("div"),
      document.querySelector("button.profile-photo-edit__container"),
      document.querySelector(".profile-photo-edit__content"),
    ].filter(Boolean)

    for (const root of photoRoots) {
      // Check <picture> sources inside these containers first
      for (const picture of root.querySelectorAll("picture")) {
        const src = picture.querySelector("source")?.srcset?.split(",")?.[0]?.trim()?.split(" ")?.[0] || ""
        if (src && isValidPhoto(src)) return upgradePhotoUrl(src)
      }
      // Then <img> tags
      for (const img of root.querySelectorAll("img")) {
        const src = imgSrc(img)
        if (isValidPhoto(src) && isSquarishImage(img)) return upgradePhotoUrl(src)
      }
    }

    // ── Strategy 2: aria-label / data-anonymize attributes ────────────────────
    for (const sel of [
      "img[data-anonymize='headshot-photo']",
      "img[aria-label*='photo' i]",
      "img[alt*='photo' i]",
      ".pv-top-card-profile-picture__image--show",
      ".profile-photo-edit__preview",
      "img[class*='EntityPhoto']",
      "img[class*='profile-photo']",
    ]) {
      try {
        for (const img of document.querySelectorAll(sel)) {
          const src = imgSrc(img)
          if (isValidPhoto(src) && isSquarishImage(img)) return upgradePhotoUrl(src)
        }
      } catch { /* bad selector */ }
    }

    // ── Strategy 3: <picture> elements anywhere, guarded by aspect ratio ──────
    // Skip strategy until we've excluded the banner: banners are wide (4:1+),
    // profile photos are square.  We use the rendered <img> size as the signal.
    for (const picture of document.querySelectorAll("picture")) {
      const src = picture.querySelector("source")?.srcset?.split(",")?.[0]?.trim()?.split(" ")?.[0] || ""
      if (!src || !isValidPhoto(src)) continue
      const img = picture.querySelector("img")
      if (img && !isSquarishImage(img)) continue  // skip banners
      return upgradePhotoUrl(src)
    }

    // ── Strategy 4: largest squarish rendered LinkedIn media image ─────────────
    // Nav avatar is ~32×32; profile photo is ≥ 200×200 at minimum.
    // Banners are excluded by the aspect-ratio guard.
    let bestSrc = null, bestArea = 0
    for (const img of document.querySelectorAll("img")) {
      const src = imgSrc(img)
      if (!isValidPhoto(src)) continue
      if (!isSquarishImage(img)) continue  // skip banners
      const w = img.naturalWidth  || img.getBoundingClientRect().width  || img.width  || 0
      const h = img.naturalHeight || img.getBoundingClientRect().height || img.height || 0
      const area = w * h
      if (area > bestArea) { bestArea = area; bestSrc = src }
    }
    if (bestSrc && bestArea >= 40000) return upgradePhotoUrl(bestSrc)  // ≥ 200×200

    // ── Strategy 5 (last resort): og:image ────────────────────────────────────
    // In LinkedIn's SPA, og:image may not update on client-side navigation and
    // can reflect a stale page.  Only use it if nothing else worked, and only
    // if the URL looks like a profile photo (not a background image).
    const og = document.querySelector('meta[property="og:image"], meta[name="og:image"]')
    if (og) {
      const src = og.content || og.getAttribute("content") || ""
      if (isValidPhoto(src) && src.includes("displayphoto")) return upgradePhotoUrl(src)
    }

    return null
  }

  function isValidPhoto(src) {
    if (!src || src.length < 10) return false
    // Exclude background/banner images — multiple URL patterns across LinkedIn versions
    if (
      src.includes("background") ||   // catches all banner URL variants
      src.includes("displaybackgroundimage") ||
      src.includes("ghost") ||
      src.includes("placeholder") ||
      src.includes("static.licdn") ||
      src.startsWith("data:") ||
      src.includes("/icons/") ||
      src.includes("icon-")
    ) return false
    // Accept any LinkedIn CDN origin
    return (
      src.includes("media.licdn.com") ||
      src.includes("mediaproxy.linkedin.com") ||
      src.includes("dms.licdn.com") ||
      src.includes("media-exp") ||
      src.includes("licdn.com")
    )
  }

  function scrapeHeadline() {
    // Prefer scoping to the top-card to avoid grabbing unrelated .text-body-medium nodes
    const topCard = document.querySelector(
      ".pv-top-card, .scaffold-layout__main > section:first-of-type, main section"
    )
    if (topCard) {
      for (const sel of [
        ".text-body-medium.break-words",
        "[data-field='headline']",
        ".text-body-medium",
        // 2024/2025 LinkedIn uses div with these combined classes
        "div.text-body-medium",
        "span.text-body-medium",
      ]) {
        try {
          for (const el of topCard.querySelectorAll(sel)) {
            const t = el?.textContent?.trim()
            // Skip short/generic text (connection count, degree badges, etc.)
            if (t && t.length > 8 && !t.match(/^\d+/) && !t.includes("connection") && !t.includes("follower")) {
              return t
            }
          }
        } catch { /* skip */ }
      }
    }
    // Fallback: document-wide, pick the first plausible headline
    for (const el of document.querySelectorAll(".text-body-medium.break-words, [data-field='headline']")) {
      const t = el?.textContent?.trim()
      if (t && t.length > 8 && !t.match(/^\d+/) && !t.includes("connection")) return t
    }
    return null
  }

  function scrapeLocation() {
    // LinkedIn's location span — try several selector forms used across versions
    for (const sel of [
      ".text-body-small.inline.t-black--light.break-words",
      "span.text-body-small.inline.t-black--light",
      ".pv-top-card--list-bullet li",
      "[data-field='location']",
      // 2025 LinkedIn: location sits directly in a <span class="text-body-small"> near the top card
      ".mt2 .text-body-small",
    ]) {
      try {
        for (const el of document.querySelectorAll(sel)) {
          const t = (el.textContent ?? "").trim()
          if (
            t.length > 3 && t.length < 100 &&
            !t.match(/^\d/) &&
            !t.includes("connection") && !t.includes("follower") &&
            !t.includes("1st") && !t.includes("2nd") && !t.includes("3rd") &&
            !t.includes("·")
          ) return t
        }
      } catch { /* skip */ }
    }

    // Broad fallback: scan all small-body text, skipping numeric/badge strings
    for (const el of document.querySelectorAll(".text-body-small")) {
      const t = (el.textContent ?? "").trim()
      if (
        t.length > 3 && t.length < 100 &&
        !t.match(/^\d/) &&
        !t.includes("connection") && !t.includes("follower") &&
        !t.includes("1st") && !t.includes("2nd") && !t.includes("3rd") &&
        (t.includes(",") || /\b(Area|Region|Greater|Metropolitan|City|County)\b/i.test(t))
      ) return t
    }
    return null
  }

  function scrapeConnectionDegree() {
    const el = q([".dist-value", ".pv-member-badge span[aria-hidden='true']", ".distance-badge span[aria-hidden='true']"])
    if (!el) return null
    const t = el.textContent.trim()
    const m = t.match(/([123])/)
    return m ? m[1] : null
  }

  function scrapeMutualConnections() {
    for (const a of document.querySelectorAll("a")) {
      const t = (a.textContent ?? "").trim()
      if (t.includes("mutual connection")) {
        const m = t.match(/(\d+)/)
        return m ? parseInt(m[1]) : null
      }
    }
    return null
  }

  function scrapeSharedConnections() {
    const currentSlug = slugFromUrl()
    const seen = new Set()
    const results = []
    const section = [...document.querySelectorAll("section")].find(
      (s) => s.textContent.includes("mutual connection")
    )
    if (!section) return results
    section.querySelectorAll("a[href*='/in/']").forEach((a) => {
      // Skip links to the profile currently being viewed
      if (a.href.toLowerCase().includes(`/in/${currentSlug}`)) return
      const name = (a.querySelector("span[aria-hidden='true']")?.textContent ?? a.textContent).trim()
      const profileUrl = a.href.split("?")[0]
      // Skip empty names and deduplicate
      if (!name || !profileUrl.includes("/in/") || seen.has(profileUrl)) return
      seen.add(profileUrl)
      results.push({ name, profileUrl })
    })
    return results
  }

  function scrapeSection(id, heading) {
    return (
      document.getElementById(id) ??
      [...document.querySelectorAll("section")].find(
        (s) => s.querySelector("h2")?.textContent?.trim().toLowerCase().includes(heading.toLowerCase())
      ) ??
      null
    )
  }

  function parseDateRange(str) {
    if (!str) return null
    const cleaned = str.replace(/·.*$/, "").trim()
    const parts = cleaned.split(/–|—/)
    return { start: parts[0]?.trim() || null, end: parts[1]?.trim() || null }
  }

  // LinkedIn shows "Company Name · Full-time" or "City, Country · On-site" — strip the suffix
  function cleanDotSuffix(s) {
    return s ? s.split("·")[0].trim() : null
  }

  // Employment-type keywords that may appear fused into the company span
  const EMP_TYPE_RE = /^(Full-time|Part-time|Self-employed|Freelance|Contract|Internship|Apprenticeship|Seasonal)$/i

  function scrapeExperience() {
    const section = scrapeSection("experience", "Experience")
    if (!section) return []
    const items = []
    const durationRe = /yr|mo|Present/i
    const dateStartRe = /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|\d{4})/

    section.querySelectorAll("li.artdeco-list__item, li[class*='pvs-list__item']").forEach((li) => {
      const allSpans = [...li.querySelectorAll("span[aria-hidden='true']")]
        .map((s) => s.textContent.trim()).filter(Boolean)
      const dateSpans = allSpans.filter((s) => durationRe.test(s) || dateStartRe.test(s))
      // Strip employment-type-only spans and date spans from text candidates
      const textSpans = allSpans.filter(
        (s) => !durationRe.test(s) && !dateStartRe.test(s) && s.length > 1 && !EMP_TYPE_RE.test(s)
      )
      if (textSpans.length === 0) return

      const nested = li.querySelectorAll("li.artdeco-list__item, li[class*='pvs-list__item']")
      if (nested.length > 0) {
        // Multi-role group: first textSpan is the company
        const company = cleanDotSuffix(textSpans[0])
        nested.forEach((role) => {
          const rs = [...role.querySelectorAll("span[aria-hidden='true']")].map((s) => s.textContent.trim()).filter(Boolean)
          const rd = rs.filter((s) => durationRe.test(s) || dateStartRe.test(s))
          const rt = rs.filter((s) => !durationRe.test(s) && !dateStartRe.test(s) && s.length > 1 && !EMP_TYPE_RE.test(s))
          if (rt[0]) items.push({ title: rt[0], company, location: cleanDotSuffix(rt[1]) ?? null, ...parseDateRange(rd[0]) })
        })
      } else {
        items.push({
          title: textSpans[0],
          company: cleanDotSuffix(textSpans[1]) ?? null,
          location: cleanDotSuffix(textSpans[2]) ?? null,
          ...parseDateRange(dateSpans[0]),
        })
      }
    })
    return items.filter((e) => e.title)
  }

  function scrapeIndustry() {
    // LinkedIn shows industry on the profile page in a few different places
    const fromAttr = text(["[data-field='industry']", "[aria-label*='industry' i]"])
    if (fromAttr) return fromAttr
    // Some layouts surface it as a small text near the top card
    for (const el of document.querySelectorAll(".text-body-small, .text-body-medium")) {
      const t = (el.textContent ?? "").trim()
      // LinkedIn industry values are typically 1–4 words, no numbers, no "·"
      if (t && t.length > 3 && t.length < 60 && !t.includes("·") && !t.match(/\d/) &&
          el.closest("[data-section='industryName'], .pv-top-card-section__industry")) return t
    }
    return null
  }

  function scrapeEducation() {
    const section = scrapeSection("education", "Education")
    if (!section) return []
    const items = []
    section.querySelectorAll("li.artdeco-list__item, li[class*='pvs-list__item']").forEach((li) => {
      const allSpans = [...li.querySelectorAll("span[aria-hidden='true']")].map((s) => s.textContent.trim()).filter(Boolean)
      const yearRe = /^\d{4}/
      const dateSpans = allSpans.filter((s) => yearRe.test(s) && s.length < 20)
      const textSpans = allSpans.filter((s) => !(yearRe.test(s) && s.length < 20) && s.length > 1)
      if (textSpans.length === 0) return
      items.push({ school: textSpans[0], degree: textSpans[1] ?? null, field: textSpans[2] ?? null, ...parseDateRange(dateSpans[0]) })
    })
    return items.filter((e) => e.school)
  }

  function extractCityCountry(location) {
    if (!location) return { city: null, country: null }
    const parts = location.split(",").map((p) => p.trim())
    return parts.length >= 2
      ? { city: parts[0], country: parts[parts.length - 1] }
      : { city: null, country: location }
  }

  function scrapeProfile() {
    const { firstName, lastName } = scrapeName()
    const location = scrapeLocation()
    const { city, country } = extractCityCountry(location)
    const profileUrl = "https://www.linkedin.com/in/" + slugFromUrl() + "/"

    const profile = {
      profileUrl,
      firstName,
      lastName,
      headline: scrapeHeadline(),
      photoUrl: scrapePhoto(),
      location,
      city,
      country,
      industry: scrapeIndustry(),
      degree: scrapeConnectionDegree(),
      commonConnections: scrapeMutualConnections(),
      sharedConnections: scrapeSharedConnections(),
      experience: scrapeExperience(),
      education: scrapeEducation(),
    }

    console.debug("[6Degrees] scraped profile:", profile)
    return profile
  }

  // ─── UI ──────────────────────────────────────────────────────────────────────

  function esc(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
  }

  function initials(first, last) {
    return ((first?.[0] ?? "") + (last?.[0] ?? "")).toUpperCase() || "?"
  }

  let panelEl = null
  let fabEl = null
  let currentProfile = null

  function injectFab() {
    if (fabEl) return
    const shadow = getShadow()

    const fab = document.createElement("button")
    fab.id = "sd-fab"
    fab.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="3" fill="white"/>
        <circle cx="4" cy="6" r="2.5" fill="white"/>
        <circle cx="20" cy="6" r="2.5" fill="white"/>
        <circle cx="4" cy="18" r="2.5" fill="white"/>
        <circle cx="20" cy="18" r="2.5" fill="white"/>
        <line x1="6.2" y1="7.3" x2="10.2" y2="10.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
        <line x1="17.8" y1="7.3" x2="13.8" y2="10.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
        <line x1="6.2" y1="16.7" x2="10.2" y2="13.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
        <line x1="17.8" y1="16.7" x2="13.8" y2="13.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
      </svg>
      Save to 6Degrees
    `
    fab.addEventListener("click", () => panelEl ? closePanel() : openPanel())
    shadow.appendChild(fab)
    fabEl = fab
  }

  function openPanel() {
    if (panelEl) return

    let p
    try {
      p = scrapeProfile()
    } catch (err) {
      console.error("[6Degrees] scrapeProfile error:", err)
      p = { profileUrl: "https://www.linkedin.com/in/" + slugFromUrl() + "/",
            firstName: humanizeSlug(slugFromUrl()).firstName,
            lastName: humanizeSlug(slugFromUrl()).lastName,
            headline: null, photoUrl: null, location: null, city: null, country: null,
            degree: null, commonConnections: null, sharedConnections: [], experience: [], education: [] }
    }
    currentProfile = p

    const shadow = getShadow()
    const panel = document.createElement("div")
    panel.id = "sd-panel"

    const avatarHtml = p.photoUrl
      ? `<img class="sd-avatar" src="${esc(p.photoUrl)}" />`
      : `<div class="sd-avatar-initials">${esc(initials(p.firstName, p.lastName))}</div>`

    const degreeBadge = p.degree ? `<span class="sd-badge">${esc(p.degree)}°</span>` : ""
    const industryBadge = p.industry ? `<span class="sd-badge">${esc(p.industry)}</span>` : ""

    const expHtml = p.experience.length > 0
      ? `<ul class="sd-list">${p.experience.map((e) => `
          <li>
            <span class="sd-list-title">${esc(e.title ?? "")}</span>
            ${e.company ? `<span class="sd-list-sub">${esc(e.company)}</span>` : ""}
            ${e.start ? `<span class="sd-list-sub">${esc(e.start)}${e.end ? " – " + esc(e.end) : ""}</span>` : ""}
          </li>`).join("")}</ul>`
      : `<p class="sd-empty">Not found — scroll the full profile first</p>`

    const eduHtml = p.education.length > 0
      ? `<ul class="sd-list">${p.education.map((e) => `
          <li>
            <span class="sd-list-title">${esc(e.school ?? "")}</span>
            ${e.degree ? `<span class="sd-list-sub">${esc(e.degree)}${e.field ? " · " + esc(e.field) : ""}</span>` : ""}
            ${e.start ? `<span class="sd-list-sub">${esc(e.start)}${e.end ? " – " + esc(e.end) : ""}</span>` : ""}
          </li>`).join("")}</ul>`
      : `<p class="sd-empty">Not found — scroll the full profile first</p>`

    const mutualHtml = p.sharedConnections.length > 0
      ? p.sharedConnections.slice(0, 8).map((sc) => `<span class="sd-badge">${esc(sc.name)}</span>`).join("") +
        (p.sharedConnections.length > 8 ? `<span class="sd-empty"> +${p.sharedConnections.length - 8} more</span>` : "")
      : p.commonConnections
        ? `<span class="sd-empty">${p.commonConnections} mutual (scroll profile to load names)</span>`
        : `<span class="sd-empty">None found</span>`

    // Show a hint if the profile loaded with almost nothing — likely the page
    // wasn't fully rendered yet.  Prompts the user to scroll then hit ↻ Refresh.
    const isEmpty = !p.headline && p.experience.length === 0 && p.education.length === 0
    const emptyHint = isEmpty
      ? `<div id="sd-empty-hint">⚠ Profile not fully loaded — scroll down then click ↻ Refresh</div>`
      : ""

    panel.innerHTML = `
      <div id="sd-panel-header">
        <h2>Save to 6Degrees</h2>
        <button id="sd-refresh" title="Re-scrape after scrolling the profile">↻</button>
        <button id="sd-close" title="Close">×</button>
      </div>
      ${emptyHint}
      <div id="sd-panel-body">
        <div class="sd-profile-header">
          ${avatarHtml}
          <div>
            <p class="sd-name">${esc((p.firstName ?? "") + " " + (p.lastName ?? "")).trim()}</p>
            ${p.headline ? `<p class="sd-headline">${esc(p.headline)}</p>` : ""}
            <div class="sd-meta">${degreeBadge}${industryBadge}${p.location ? esc(p.location) : ""}${p.commonConnections != null ? ` · ${p.commonConnections} mutual` : ""}</div>
          </div>
        </div>
        <div class="sd-section"><p class="sd-section-title">Experience</p>${expHtml}</div>
        <div class="sd-section"><p class="sd-section-title">Education</p>${eduHtml}</div>
        <div class="sd-section"><p class="sd-section-title">Mutual connections</p>${mutualHtml}</div>
      </div>
      <div id="sd-panel-footer">
        <button id="sd-save-btn">Save contact</button>
        <span id="sd-status"></span>
      </div>
    `

    shadow.appendChild(panel)
    panelEl = panel

    panel.querySelector("#sd-close").addEventListener("click", closePanel)
    panel.querySelector("#sd-save-btn").addEventListener("click", saveContact)
    panel.querySelector("#sd-refresh").addEventListener("click", () => {
      closePanel()
      openPanel()
    })
  }

  function closePanel() {
    panelEl?.remove()
    panelEl = null
  }

  async function saveContact() {
    const btn = panelEl?.querySelector("#sd-save-btn")
    const status = panelEl?.querySelector("#sd-status")
    if (!btn || !status) return

    btn.disabled = true
    btn.textContent = "Saving…"
    status.textContent = ""
    status.className = ""

    let result
    try {
      result = await Promise.race([
        new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ type: "ENRICH_CONTACT", data: currentProfile }, (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message || "Extension messaging error"))
            } else {
              resolve(response)
            }
          })
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Timed out — check API URL and token in the popup")), 15000)
        ),
      ])
    } catch (err) {
      result = { ok: false, error: err.message }
    }

    btn.disabled = false
    btn.textContent = "Save contact"

    if (result?.ok) {
      status.textContent = result.action === "created" ? "✓ Contact created!" : "✓ Contact updated!"
      status.className = "ok"
      setTimeout(closePanel, 1800)
    } else {
      status.textContent = result?.error || "Something went wrong"
      status.className = "err"
    }
  }

  // ─── Init & SPA navigation ────────────────────────────────────────────────────

  function init() {
    if (!window.location.pathname.startsWith("/in/")) return
    // Wait 3 seconds — LinkedIn's SPA lazily renders the profile sections and
    // the 1.5 s delay was too short for slower connections / large profiles.
    setTimeout(injectFab, 3000)
  }

  let lastPath = location.pathname
  new MutationObserver(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname
      closePanel()
      fabEl?.remove()
      fabEl = null
      init()
    }
  }).observe(document.body, { childList: true, subtree: false })

  init()
})()
